//
//  Model .swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 02/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import Foundation
struct Welcome: Codable {
   var results: [Result]
  }
struct Result: Codable {
  var id: Int
 var popularity: Double
var title: String
var poster_path: String
}

























