//
//  MovieViewController.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 03/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit
class MovieData{
    var Movietype : String?
    var Moviename : [String]?
    
    init(Movietype: String, Moviename: [String]){
        self.Movietype = Movietype
        self.Moviename = Moviename
    }
}
class MovieViewController: UIViewController {
 var movieDataList : Welcome?
 var movieData = [MovieData]()
    override func viewDidLoad() {
        super.viewDidLoad()
        movieData.append(MovieData.init(Movietype: "Discover recommended Movie", Moviename: ["Action Movies"]))
        movieData.append(MovieData.init(Movietype: "Suggested for You", Moviename: ["Monster Movies"]))
        movieData.append(MovieData.init(Movietype: "Suggested for You", Moviename: ["Adventure Movies"]))
        jsonPasring()
}
func jsonPasring(){
           let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=60af9fe8e3245c53ad9c4c0af82d56d6&language=en-US&page=1")
           URLSession.shared.dataTask(with: url!) { (data, response, error)
               in
               guard let data = data else { return }
               do{
                   self.movieDataList = try? JSONDecoder().decode(Welcome.self, from: data)
                  
               }catch{
                   print(error.localizedDescription)
               }
    }.resume()
       }
}
extension MovieViewController: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.movieData.count
    }
 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
}
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MovieCell
        if let data = self.movieDataList {
            cell.getDataFromVC(model: self.movieDataList!.results)
        }
        else
            {
                
            }
            return cell
        }
        func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            
            return movieData[section].Movietype
            
        }
    }

