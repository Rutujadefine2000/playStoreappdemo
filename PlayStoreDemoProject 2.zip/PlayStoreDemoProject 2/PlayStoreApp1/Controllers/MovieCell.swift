//
//  MovieCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 03/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit
extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleToFill) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleToFill) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
class MovieCell: UITableViewCell {
   @IBOutlet weak var mtlbl: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    var movieList: [Result] = []
    override func awakeFromNib() {
        super.awakeFromNib()
     collectionView.delegate = self
        collectionView.dataSource = self
    }
    func getDataFromVC(model: [Result]) {
        self.movieList = model
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
extension MovieCell : UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //return arrData.count
        return movieList.count
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectioncell", for: indexPath) as? CollectionViewCell
       cell?.titleLabel.text = movieList[indexPath.row].title
      cell?.idLabel.text = String(movieList[indexPath.row].id)
        cell?.popularityLabel.text = String(movieList[indexPath.row].popularity)
        
        cell?.imageView1.contentMode = .scaleAspectFill
        cell?.imageView2.contentMode = .scaleAspectFill
        cell?.imageView1.clipsToBounds = false
        cell?.imageView2.clipsToBounds = false
        let defaultsLink = "https://image.tmdb.org/t/p/w200"
        let completeLink = defaultsLink + movieList[indexPath.row].poster_path
        cell?.imageView1.downloaded(from: completeLink)
        cell?.imageView2.downloaded(from: completeLink)
        cell?.imageView1.layer.cornerRadius = 10.0
        cell?.imageView1.clipsToBounds = true
        cell?.imageView2.layer.cornerRadius = 10.0
        cell?.imageView2.clipsToBounds = true
        return cell!
    }
}
extension UIImageView {
    func makeRoundCorners(byRadius rad: CGFloat){
        self.layer.cornerRadius = rad
        self.clipsToBounds = true
    }
}



